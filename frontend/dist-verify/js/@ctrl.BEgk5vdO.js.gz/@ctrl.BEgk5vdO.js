function t(t,e){(function(t){return"string"==typeof t&&-1!==t.indexOf(".")&&1===parseFloat(t)})(t)&&(t="100%");const r=function(t){return"string"==typeof t&&-1!==t.indexOf("%")}(t);return t=360===e?t:Math.min(e,Math.max(0,parseFloat(t))),r&&(t=parseInt(String(t*e),10)/100),Math.abs(t-e)<1e-6?1:t=360===e?(t<0?t%e+e:t%e)/parseFloat(String(e)):t%e/parseFloat(String(e))}function e(t){return Math.min(1,Math.max(0,t))}function r(t){return t=parseFloat(t),(isNaN(t)||t<0||t>1)&&(t=1),t}function a(t){return Number(t)<=1?100*Number(t)+"%":t}function n(t){return 1===t.length?"0"+t:String(t)}function s(e,r,a){e=t(e,255),r=t(r,255),a=t(a,255);const n=Math.max(e,r,a),s=Math.min(e,r,a);let i=0,h=0;const o=(n+s)/2;if(n===s)h=0,i=0;else{const t=n-s;switch(h=o>.5?t/(2-n-s):t/(n+s),n){case e:i=(r-a)/t+(r<a?6:0);break;case r:i=(a-e)/t+2;break;case a:i=(e-r)/t+4}i/=6}return{h:i,s:h,l:o}}function i(t,e,r){return r<0&&(r+=1),r>1&&(r-=1),r<1/6?t+6*r*(e-t):r<.5?e:r<2/3?t+(e-t)*(2/3-r)*6:t}function h(e,r,a){e=t(e,255),r=t(r,255),a=t(a,255);const n=Math.max(e,r,a),s=Math.min(e,r,a);let i=0;const h=n,o=n-s,f=0===n?0:o/n;if(n===s)i=0;else{switch(n){case e:i=(r-a)/o+(r<a?6:0);break;case r:i=(a-e)/o+2;break;case a:i=(e-r)/o+4}i/=6}return{h:i,s:f,v:h}}function o(t,e,r,a){const s=[n(Math.round(t).toString(16)),n(Math.round(e).toString(16)),n(Math.round(r).toString(16))];return a&&s[0].startsWith(s[0].charAt(1))&&s[1].startsWith(s[1].charAt(1))&&s[2].startsWith(s[2].charAt(1))?s[0].charAt(0)+s[1].charAt(0)+s[2].charAt(0):s.join("")}function f(t,e,r){let a=1-t/255,n=1-e/255,s=1-r/255,i=Math.min(a,n,s);return 1===i?(a=0,n=0,s=0):(a=(a-i)/(1-i)*100,n=(n-i)/(1-i)*100,s=(s-i)/(1-i)*100),i*=100,{c:Math.round(a),m:Math.round(n),y:Math.round(s),k:Math.round(i)}}function u(t){return g(t)/255}function g(t){return parseInt(t,16)}const c={aliceblue:"#f0f8ff",antiquewhite:"#faebd7",aqua:"#00ffff",aquamarine:"#7fffd4",azure:"#f0ffff",beige:"#f5f5dc",bisque:"#ffe4c4",black:"#000000",blanchedalmond:"#ffebcd",blue:"#0000ff",blueviolet:"#8a2be2",brown:"#a52a2a",burlywood:"#deb887",cadetblue:"#5f9ea0",chartreuse:"#7fff00",chocolate:"#d2691e",coral:"#ff7f50",cornflowerblue:"#6495ed",cornsilk:"#fff8dc",crimson:"#dc143c",cyan:"#00ffff",darkblue:"#00008b",darkcyan:"#008b8b",darkgoldenrod:"#b8860b",darkgray:"#a9a9a9",darkgreen:"#006400",darkgrey:"#a9a9a9",darkkhaki:"#bdb76b",darkmagenta:"#8b008b",darkolivegreen:"#556b2f",darkorange:"#ff8c00",darkorchid:"#9932cc",darkred:"#8b0000",darksalmon:"#e9967a",darkseagreen:"#8fbc8f",darkslateblue:"#483d8b",darkslategray:"#2f4f4f",darkslategrey:"#2f4f4f",darkturquoise:"#00ced1",darkviolet:"#9400d3",deeppink:"#ff1493",deepskyblue:"#00bfff",dimgray:"#696969",dimgrey:"#696969",dodgerblue:"#1e90ff",firebrick:"#b22222",floralwhite:"#fffaf0",forestgreen:"#228b22",fuchsia:"#ff00ff",gainsboro:"#dcdcdc",ghostwhite:"#f8f8ff",goldenrod:"#daa520",gold:"#ffd700",gray:"#808080",green:"#008000",greenyellow:"#adff2f",grey:"#808080",honeydew:"#f0fff0",hotpink:"#ff69b4",indianred:"#cd5c5c",indigo:"#4b0082",ivory:"#fffff0",khaki:"#f0e68c",lavenderblush:"#fff0f5",lavender:"#e6e6fa",lawngreen:"#7cfc00",lemonchiffon:"#fffacd",lightblue:"#add8e6",lightcoral:"#f08080",lightcyan:"#e0ffff",lightgoldenrodyellow:"#fafad2",lightgray:"#d3d3d3",lightgreen:"#90ee90",lightgrey:"#d3d3d3",lightpink:"#ffb6c1",lightsalmon:"#ffa07a",lightseagreen:"#20b2aa",lightskyblue:"#87cefa",lightslategray:"#778899",lightslategrey:"#778899",lightsteelblue:"#b0c4de",lightyellow:"#ffffe0",lime:"#00ff00",limegreen:"#32cd32",linen:"#faf0e6",magenta:"#ff00ff",maroon:"#800000",mediumaquamarine:"#66cdaa",mediumblue:"#0000cd",mediumorchid:"#ba55d3",mediumpurple:"#9370db",mediumseagreen:"#3cb371",mediumslateblue:"#7b68ee",mediumspringgreen:"#00fa9a",mediumturquoise:"#48d1cc",mediumvioletred:"#c71585",midnightblue:"#191970",mintcream:"#f5fffa",mistyrose:"#ffe4e1",moccasin:"#ffe4b5",navajowhite:"#ffdead",navy:"#000080",oldlace:"#fdf5e6",olive:"#808000",olivedrab:"#6b8e23",orange:"#ffa500",orangered:"#ff4500",orchid:"#da70d6",palegoldenrod:"#eee8aa",palegreen:"#98fb98",paleturquoise:"#afeeee",palevioletred:"#db7093",papayawhip:"#ffefd5",peachpuff:"#ffdab9",peru:"#cd853f",pink:"#ffc0cb",plum:"#dda0dd",powderblue:"#b0e0e6",purple:"#800080",rebeccapurple:"#663399",red:"#ff0000",rosybrown:"#bc8f8f",royalblue:"#4169e1",saddlebrown:"#8b4513",salmon:"#fa8072",sandybrown:"#f4a460",seagreen:"#2e8b57",seashell:"#fff5ee",sienna:"#a0522d",silver:"#c0c0c0",skyblue:"#87ceeb",slateblue:"#6a5acd",slategray:"#708090",slategrey:"#708090",snow:"#fffafa",springgreen:"#00ff7f",steelblue:"#4682b4",tan:"#d2b48c",teal:"#008080",thistle:"#d8bfd8",tomato:"#ff6347",turquoise:"#40e0d0",violet:"#ee82ee",wheat:"#f5deb3",white:"#ffffff",whitesmoke:"#f5f5f5",yellow:"#ffff00",yellowgreen:"#9acd32"};function l(e){let n={r:0,g:0,b:0},s=1,h=null,o=null,f=null,l=!1,d=!1;var b,m,y;return"string"==typeof e&&(e=function(t){if(t=t.trim().toLowerCase(),0===t.length)return!1;let e=!1;if(c[t])t=c[t],e=!0;else if("transparent"===t)return{r:0,g:0,b:0,a:0,format:"name"};let r=p.rgb.exec(t);if(r)return{r:r[1],g:r[2],b:r[3]};if(r=p.rgba.exec(t),r)return{r:r[1],g:r[2],b:r[3],a:r[4]};if(r=p.hsl.exec(t),r)return{h:r[1],s:r[2],l:r[3]};if(r=p.hsla.exec(t),r)return{h:r[1],s:r[2],l:r[3],a:r[4]};if(r=p.hsv.exec(t),r)return{h:r[1],s:r[2],v:r[3]};if(r=p.hsva.exec(t),r)return{h:r[1],s:r[2],v:r[3],a:r[4]};if(r=p.cmyk.exec(t),r)return{c:r[1],m:r[2],y:r[3],k:r[4]};if(r=p.hex8.exec(t),r)return{r:g(r[1]),g:g(r[2]),b:g(r[3]),a:u(r[4]),format:e?"name":"hex8"};if(r=p.hex6.exec(t),r)return{r:g(r[1]),g:g(r[2]),b:g(r[3]),format:e?"name":"hex"};if(r=p.hex4.exec(t),r)return{r:g(r[1]+r[1]),g:g(r[2]+r[2]),b:g(r[3]+r[3]),a:u(r[4]+r[4]),format:e?"name":"hex8"};if(r=p.hex3.exec(t),r)return{r:g(r[1]+r[1]),g:g(r[2]+r[2]),b:g(r[3]+r[3]),format:e?"name":"hex"};return!1}(e)),"object"==typeof e&&(x(e.r)&&x(e.g)&&x(e.b)?(b=e.r,m=e.g,y=e.b,n={r:255*t(b,255),g:255*t(m,255),b:255*t(y,255)},l=!0,d="%"===String(e.r).substr(-1)?"prgb":"rgb"):x(e.h)&&x(e.s)&&x(e.v)?(h=a(e.s),o=a(e.v),n=function(e,r,a){e=6*t(e,360),r=t(r,100),a=t(a,100);const n=Math.floor(e),s=e-n,i=a*(1-r),h=a*(1-s*r),o=a*(1-(1-s)*r),f=n%6;return{r:255*[a,h,i,i,o,a][f],g:255*[o,a,a,h,i,i][f],b:255*[i,i,o,a,a,h][f]}}(e.h,h,o),l=!0,d="hsv"):x(e.h)&&x(e.s)&&x(e.l)?(h=a(e.s),f=a(e.l),n=function(e,r,a){let n,s,h;if(e=t(e,360),r=t(r,100),a=t(a,100),0===r)s=a,h=a,n=a;else{const t=a<.5?a*(1+r):a+r-a*r,o=2*a-t;n=i(o,t,e+1/3),s=i(o,t,e),h=i(o,t,e-1/3)}return{r:255*n,g:255*s,b:255*h}}(e.h,h,f),l=!0,d="hsl"):x(e.c)&&x(e.m)&&x(e.y)&&x(e.k)&&(n=function(t,e,r,a){const n=a/100;return{r:255*(1-t/100)*(1-n),g:255*(1-e/100)*(1-n),b:255*(1-r/100)*(1-n)}}(e.c,e.m,e.y,e.k),l=!0,d="cmyk"),Object.prototype.hasOwnProperty.call(e,"a")&&(s=e.a)),s=r(s),{ok:l,format:e.format||d,r:Math.min(255,Math.max(n.r,0)),g:Math.min(255,Math.max(n.g,0)),b:Math.min(255,Math.max(n.b,0)),a:s}}const d="(?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?)",b="[\\s|\\(]+("+d+")[,|\\s]+("+d+")[,|\\s]+("+d+")\\s*\\)?",m=
// eslint-disable-next-line prettier/prettier
"[\\s|\\(]+("+d+")[,|\\s]+("+d+")[,|\\s]+("+d+")[,|\\s]+("+d+")\\s*\\)?",p={CSS_UNIT:new RegExp(d),rgb:new RegExp("rgb"+b),rgba:new RegExp("rgba"+m),hsl:new RegExp("hsl"+b),hsla:new RegExp("hsla"+m),hsv:new RegExp("hsv"+b),hsva:new RegExp("hsva"+m),cmyk:new RegExp("cmyk"+m),hex3:/^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,hex6:/^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,hex4:/^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,hex8:/^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/};function x(t){return"number"==typeof t?!Number.isNaN(t):p.CSS_UNIT.test(t)}class y{constructor(t="",e={}){if(t instanceof y)return t;"number"==typeof t&&(t=function(t){return{r:t>>16,g:(65280&t)>>8,b:255&t}}(t)),this.originalInput=t;const r=l(t);this.originalInput=t,this.r=r.r,this.g=r.g,this.b=r.b,this.a=r.a,this.roundA=Math.round(100*this.a)/100,this.format=e.format??r.format,this.gradientType=e.gradientType,this.r<1&&(this.r=Math.round(this.r)),this.g<1&&(this.g=Math.round(this.g)),this.b<1&&(this.b=Math.round(this.b)),this.isValid=r.ok}isDark(){return this.getBrightness()<128}isLight(){return!this.isDark()}
/**
   * Returns the perceived brightness of the color, from 0-255.
   */getBrightness(){const t=this.toRgb();return(299*t.r+587*t.g+114*t.b)/1e3}
/**
   * Returns the perceived luminance of a color, from 0-1.
   */getLuminance(){const t=this.toRgb();let e,r,a;const n=t.r/255,s=t.g/255,i=t.b/255;return e=n<=.03928?n/12.92:Math.pow((n+.055)/1.055,2.4),r=s<=.03928?s/12.92:Math.pow((s+.055)/1.055,2.4),a=i<=.03928?i/12.92:Math.pow((i+.055)/1.055,2.4),.2126*e+.7152*r+.0722*a}
/**
   * Returns the alpha value of a color, from 0-1.
   */getAlpha(){return this.a}
/**
   * Sets the alpha value on the current color.
   *
   * @param alpha - The new alpha value. The accepted range is 0-1.
   */setAlpha(t){return this.a=r(t),this.roundA=Math.round(100*this.a)/100,this}
/**
   * Returns whether the color is monochrome.
   */isMonochrome(){const{s:t}=this.toHsl();return 0===t}
/**
   * Returns the object as a HSVA object.
   */toHsv(){const t=h(this.r,this.g,this.b);return{h:360*t.h,s:t.s,v:t.v,a:this.a}}
/**
   * Returns the hsva values interpolated into a string with the following format:
   * "hsva(xxx, xxx, xxx, xx)".
   */toHsvString(){const t=h(this.r,this.g,this.b),e=Math.round(360*t.h),r=Math.round(100*t.s),a=Math.round(100*t.v);return 1===this.a?`hsv(${e}, ${r}%, ${a}%)`:`hsva(${e}, ${r}%, ${a}%, ${this.roundA})`}
/**
   * Returns the object as a HSLA object.
   */toHsl(){const t=s(this.r,this.g,this.b);return{h:360*t.h,s:t.s,l:t.l,a:this.a}}
/**
   * Returns the hsla values interpolated into a string with the following format:
   * "hsla(xxx, xxx, xxx, xx)".
   */toHslString(){const t=s(this.r,this.g,this.b),e=Math.round(360*t.h),r=Math.round(100*t.s),a=Math.round(100*t.l);return 1===this.a?`hsl(${e}, ${r}%, ${a}%)`:`hsla(${e}, ${r}%, ${a}%, ${this.roundA})`}
/**
   * Returns the hex value of the color.
   * @param allow3Char will shorten hex value to 3 char if possible
   */toHex(t=!1){return o(this.r,this.g,this.b,t)}
/**
   * Returns the hex value of the color -with a # prefixed.
   * @param allow3Char will shorten hex value to 3 char if possible
   */toHexString(t=!1){return"#"+this.toHex(t)}
/**
   * Returns the hex 8 value of the color.
   * @param allow4Char will shorten hex value to 4 char if possible
   */toHex8(t=!1){return function(t,e,r,a,s){const i=[n(Math.round(t).toString(16)),n(Math.round(e).toString(16)),n(Math.round(r).toString(16)),n((h=a,Math.round(255*parseFloat(h)).toString(16)))];var h;return s&&i[0].startsWith(i[0].charAt(1))&&i[1].startsWith(i[1].charAt(1))&&i[2].startsWith(i[2].charAt(1))&&i[3].startsWith(i[3].charAt(1))?i[0].charAt(0)+i[1].charAt(0)+i[2].charAt(0)+i[3].charAt(0):i.join("")}(this.r,this.g,this.b,this.a,t)}
/**
   * Returns the hex 8 value of the color -with a # prefixed.
   * @param allow4Char will shorten hex value to 4 char if possible
   */toHex8String(t=!1){return"#"+this.toHex8(t)}
/**
   * Returns the shorter hex value of the color depends on its alpha -with a # prefixed.
   * @param allowShortChar will shorten hex value to 3 or 4 char if possible
   */toHexShortString(t=!1){return 1===this.a?this.toHexString(t):this.toHex8String(t)}
/**
   * Returns the object as a RGBA object.
   */toRgb(){return{r:Math.round(this.r),g:Math.round(this.g),b:Math.round(this.b),a:this.a}}
/**
   * Returns the RGBA values interpolated into a string with the following format:
   * "RGBA(xxx, xxx, xxx, xx)".
   */toRgbString(){const t=Math.round(this.r),e=Math.round(this.g),r=Math.round(this.b);return 1===this.a?`rgb(${t}, ${e}, ${r})`:`rgba(${t}, ${e}, ${r}, ${this.roundA})`}
/**
   * Returns the object as a RGBA object.
   */toPercentageRgb(){const e=e=>`${Math.round(100*t(e,255))}%`;return{r:e(this.r),g:e(this.g),b:e(this.b),a:this.a}}
/**
   * Returns the RGBA relative values interpolated into a string
   */toPercentageRgbString(){const e=e=>Math.round(100*t(e,255));return 1===this.a?`rgb(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%)`:`rgba(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%, ${this.roundA})`}toCmyk(){return{...f(this.r,this.g,this.b)}}toCmykString(){const{c:t,m:e,y:r,k:a}=f(this.r,this.g,this.b);return`cmyk(${t}, ${e}, ${r}, ${a})`}
/**
   * The 'real' name of the color -if there is one.
   */toName(){if(0===this.a)return"transparent";if(this.a<1)return!1;const t="#"+o(this.r,this.g,this.b,!1);for(const[e,r]of Object.entries(c))if(t===r)return e;return!1}toString(t){const e=Boolean(t);t=t??this.format;let r=!1;const a=this.a<1&&this.a>=0;return e||!a||!t.startsWith("hex")&&"name"!==t?("rgb"===t&&(r=this.toRgbString()),"prgb"===t&&(r=this.toPercentageRgbString()),"hex"!==t&&"hex6"!==t||(r=this.toHexString()),"hex3"===t&&(r=this.toHexString(!0)),"hex4"===t&&(r=this.toHex8String(!0)),"hex8"===t&&(r=this.toHex8String()),"name"===t&&(r=this.toName()),"hsl"===t&&(r=this.toHslString()),"hsv"===t&&(r=this.toHsvString()),"cmyk"===t&&(r=this.toCmykString()),r||this.toHexString()):"name"===t&&0===this.a?this.toName():this.toRgbString()}toNumber(){return(Math.round(this.r)<<16)+(Math.round(this.g)<<8)+Math.round(this.b)}clone(){return new y(this.toString())}
/**
   * Lighten the color a given amount. Providing 100 will always return white.
   * @param amount - valid between 1-100
   */lighten(t=10){const r=this.toHsl();return r.l+=t/100,r.l=e(r.l),new y(r)}
/**
   * Brighten the color a given amount, from 0 to 100.
   * @param amount - valid between 1-100
   */brighten(t=10){const e=this.toRgb();return e.r=Math.max(0,Math.min(255,e.r-Math.round(-t/100*255))),e.g=Math.max(0,Math.min(255,e.g-Math.round(-t/100*255))),e.b=Math.max(0,Math.min(255,e.b-Math.round(-t/100*255))),new y(e)}
/**
   * Darken the color a given amount, from 0 to 100.
   * Providing 100 will always return black.
   * @param amount - valid between 1-100
   */darken(t=10){const r=this.toHsl();return r.l-=t/100,r.l=e(r.l),new y(r)}
/**
   * Mix the color with pure white, from 0 to 100.
   * Providing 0 will do nothing, providing 100 will always return white.
   * @param amount - valid between 1-100
   */tint(t=10){return this.mix("white",t)}
/**
   * Mix the color with pure black, from 0 to 100.
   * Providing 0 will do nothing, providing 100 will always return black.
   * @param amount - valid between 1-100
   */shade(t=10){return this.mix("black",t)}
/**
   * Desaturate the color a given amount, from 0 to 100.
   * Providing 100 will is the same as calling greyscale
   * @param amount - valid between 1-100
   */desaturate(t=10){const r=this.toHsl();return r.s-=t/100,r.s=e(r.s),new y(r)}
/**
   * Saturate the color a given amount, from 0 to 100.
   * @param amount - valid between 1-100
   */saturate(t=10){const r=this.toHsl();return r.s+=t/100,r.s=e(r.s),new y(r)}
/**
   * Completely desaturates a color into greyscale.
   * Same as calling `desaturate(100)`
   */greyscale(){return this.desaturate(100)}
/**
   * Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
   * Values outside of this range will be wrapped into this range.
   */spin(t){const e=this.toHsl(),r=(e.h+t)%360;return e.h=r<0?360+r:r,new y(e)}
/**
   * Mix the current color a given amount with another color, from 0 to 100.
   * 0 means no mixing (return current color).
   */mix(t,e=50){const r=this.toRgb(),a=new y(t).toRgb(),n=e/100,s={r:(a.r-r.r)*n+r.r,g:(a.g-r.g)*n+r.g,b:(a.b-r.b)*n+r.b,a:(a.a-r.a)*n+r.a};return new y(s)}analogous(t=6,e=30){const r=this.toHsl(),a=360/e,n=[this];for(r.h=(r.h-(a*t>>1)+720)%360;--t;)r.h=(r.h+a)%360,n.push(new y(r));return n}
/**
   * taken from https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js
   */complement(){const t=this.toHsl();return t.h=(t.h+180)%360,new y(t)}monochromatic(t=6){const e=this.toHsv(),{h:r}=e,{s:a}=e;let{v:n}=e;const s=[],i=1/t;for(;t--;)s.push(new y({h:r,s:a,v:n})),n=(n+i)%1;return s}splitcomplement(){const t=this.toHsl(),{h:e}=t;return[this,new y({h:(e+72)%360,s:t.s,l:t.l}),new y({h:(e+216)%360,s:t.s,l:t.l})]}
/**
   * Compute how the color would appear on a background
   */onBackground(t){const e=this.toRgb(),r=new y(t).toRgb(),a=e.a+r.a*(1-e.a);return new y({r:(e.r*e.a+r.r*r.a*(1-e.a))/a,g:(e.g*e.a+r.g*r.a*(1-e.a))/a,b:(e.b*e.a+r.b*r.a*(1-e.a))/a,a:a})}
/**
   * Alias for `polyad(3)`
   */triad(){return this.polyad(3)}
/**
   * Alias for `polyad(4)`
   */tetrad(){return this.polyad(4)}
/**
   * Get polyad colors, like (for 1, 2, 3, 4, 5, 6, 7, 8, etc...)
   * monad, dyad, triad, tetrad, pentad, hexad, heptad, octad, etc...
   */polyad(t){const e=this.toHsl(),{h:r}=e,a=[this],n=360/t;for(let s=1;s<t;s++)a.push(new y({h:(r+s*n)%360,s:e.s,l:e.l}));return a}
/**
   * compare color vs current color
   */equals(t){const e=new y(t);return"cmyk"===this.format||"cmyk"===e.format?this.toCmykString()===e.toCmykString():this.toRgbString()===e.toRgbString()}}export{y as T};
